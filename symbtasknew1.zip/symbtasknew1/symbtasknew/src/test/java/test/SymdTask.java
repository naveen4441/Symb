package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class SymdTask {
	

	   private static final Logger logger = LogManager.getLogger(SymdTask.class); // Initialize logger
       WebDriver driver;
       //WebDriverWait wait = new WebDriverWait(driver,30);
	    @BeforeClass
	    public void setup() {
	        // Initialize the WebDriver and open the URL
	    	logger.info("Setting up the WebDriver and opening the URL");
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.get("https://d3pv22lioo8876.cloudfront.net/tiptop/");
	        logger.info("Navigated to the URL successfully");
	    }

	    @Test(priority = 1)
	    public void verifyDisabledInput() {
	    	logger.info("Verifying that the input is disabled");
	        // Verify that the input is disabled
	        WebElement disabledInput = driver.findElement(By.xpath("(//input[@name='my-disabled'])[1]"));
	        Assert.assertFalse(disabledInput.isEnabled(), "Input is not disabled");
	        logger.info("Verified that the input is disabled successfully");
	    }

	    @Test(priority = 2)
	    public void verifyReadonlyInput() {
	    	logger.info("Verifying readonly input fields");
	        // Verify readonly input using two xpaths
	        WebElement readonlyInput1 = driver.findElement(By.xpath("//input[@value='Readonly input']"));
	        WebElement readonlyInput2 = driver.findElement(By.xpath("//input[@readonly and @value='Readonly input']"));

	        Assert.assertTrue(readonlyInput1.getAttribute("readonly").equals("true"), "Input is readonly with 1st xpath");
	        logger.info("Verified readonly input fields successfully with Xpath1");
	        Assert.assertTrue(readonlyInput2.getAttribute("readonly").equals("true"), "Input is readonly (2nd XPath)");
	        logger.info("Verified readonly input fields successfully with Xpath2");
	    }

	    @Test(priority = 3)
	    public void verifyDropdownElements() {
	    	logger.info("Verifying the dropdown elements");
	        // Verify the dropdown has 8 elements using two xpaths
	        //WebElement dropdown = driver.findElement(By.xpath("//select[@name='my-select']"));
	        List<WebElement> options1 = driver.findElements(By.tagName("option"));
	        Assert.assertEquals(options1.size(), 8, "Dropdown have 8 options using 1st Xpath");

	        List<WebElement> options2 = driver.findElements(By.xpath("//select[@name='my-select']/option"));
	        Assert.assertEquals(options2.size(), 8, "Dropdown does 8 options using 2nd xpath");
	        logger.info("Verified dropdown elements successfully");
	    }

	    @Test(priority = 4)
	    public void verifySubmitButtonDisabled() {
	    	logger.info("Verifying that the submit button is disabled when Name & Password fields are empty");
	        // Verify the submit button is disabled when the Name field is empty
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        Assert.assertFalse(submitButton.isEnabled(), "Submit button is disabled when Name & password field is empty");
	        logger.info("Verified that submit button is disabled successfully");
	    }

	    @Test(priority = 5)
	    public void verifySubmitButtonEnabledwithNameAndPassword() throws InterruptedException {
	    	logger.info("Verifying that the submit button is enabled when Name and Password fields are filled");
	        // Verify the submit button is enabled when Name and Password fields are filled
	        WebElement nameInput = driver.findElement(By.xpath("//input[@name='my-name']"));
	        nameInput.sendKeys("Naveen");
	        WebElement passwordInput = driver.findElement(By.xpath("//input[@name='my-password']"));
	        
	        passwordInput.sendKeys("naveen");
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        
	        Thread.sleep(4000);

	        Assert.assertTrue(submitButton.isEnabled(), "Submit button is  enabled after filling Name and Password");
	        logger.info("Verified that submit button is enabled successfully");
	    }

	    @Test(priority = 6)
	    public void verifySubmitDisplaysReceivedText() throws InterruptedException {
	    	logger.info("Verifying the 'Received' text after form submission");
	        // Verify the page shows "Received" text upon submission
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        submitButton.click();
            Thread.sleep(4000);
	        WebElement receivedText = driver.findElement(By.xpath("//p[contains(text(), 'Received')]"));
	        String recivedActual=receivedText.getText().replace("!", "");
	        Assert.assertEquals(recivedActual, "Received", "'Received' text displayed after submission");
	        logger.info("Verified that 'Received' text is displayed successfully");
	    }

	    @Test(priority = 7)
	    public void verifyFormDataInURL() {
	    	logger.info("Verifying form data in the URL");
	        // Verify all form data is passed to the URL
	        String currentUrl = driver.getCurrentUrl();
	        Assert.assertTrue(currentUrl.contains("name=Naveen"), "Name data  passed in URL");
	        logger.info("Verified that nane is present in the URL");
	        
	        Assert.assertTrue(currentUrl.contains("password=naveen"), "Password data passed in URL");
	        logger.info("Verified that password is present in the URL");
	        
            Assert.assertTrue(currentUrl.contains("my-readonly=Readonly"), "Readonly field data  passed in URL");
            logger.info("Verified that readonly is present in the URL");
            
	        Assert.assertTrue(currentUrl.contains("my-select=white"), "Select color data passed in URL");
	        logger.info("Verified that colur is present in the URL");

	    }

	  
		@AfterClass
	    public void tearDown() {
			logger.info("Tearing down the WebDriver and closing the browser");
	        // Close the browser
	        if (driver != null) {
	            driver.quit();
	        logger.info("Browser closed successfully");
	        }
	    }
	}

